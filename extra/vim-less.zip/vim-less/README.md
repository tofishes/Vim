vim-less
========

Vim support for LESS CSS

* syntax highlight.
* indent support.
* compile the file.less to file.css if you have lessc installed, and echo any errors.
